/* ============================================================
   后台管理系统 · 交互逻辑
   说明：纯原生 JS，无依赖，方便直接拷贝 / iframe 接入。
   接入真实后端时，只需把 render 里的「示例数据」换成接口请求即可。
   ============================================================ */
(function () {
  'use strict';

  /* ---------------- 登录页 ---------------- */
  var loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var u = document.getElementById('username').value.trim();
      var p = document.getElementById('password').value.trim();
      var err = document.getElementById('loginError');
      // 演示校验：admin / 123456
      if (u === 'admin' && p === '123456') {
        localStorage.setItem('admin_token', 'demo-token-' + Date.now());
        localStorage.setItem('admin_user', u);
        window.location.href = 'admin.html';
      } else {
        err.textContent = '用户名或密码错误（演示账号 admin / 123456）';
      }
    });
    return; // 登录页不再执行后台逻辑
  }

  /* ---------------- 后台页守卫 ---------------- */
  var layout = document.getElementById('sidebar');
  if (!layout) return;
  if (!localStorage.getItem('admin_token')) {
    window.location.href = 'index.html';
    return;
  }

  /* ---------------- 示例数据（接后端时替换此处） ---------------- */
  var users = [];
  var roles = ['管理员', '编辑', '访客'];
  for (var i = 1; i <= 23; i++) {
    users.push({
      id: i,
      name: i === 1 ? 'admin' : ('user' + i),
      email: 'user' + i + '@sky.com',
      role: i === 1 ? '管理员' : roles[i % 3],
      status: (i % 5 === 0) ? '禁用' : '启用'
    });
  }

  var contents = [];
  var cats = ['Java', '前端', 'HarmonyOS', '随笔', '教程'];
  var titles = [
    'Java 基础语法入门', 'Vue3 响应式原理解析', 'ArkTS 组件开发实战',
    '集合框架 ArrayList 详解', '并发编程 Thread 入门', 'Stream API 流式处理',
    'Lambda 表达式精讲', '异常处理最佳实践', '泛型与通配符', 'IO 与 NIO 对比',
    '反射机制浅析', '注解 Annotation 用法', 'JVM 内存模型', 'GC 垃圾回收',
    '设计模式之单例', 'StringBuilder 优化', '枚举 Enum 实战', 'Optional 空值处理'
  ];
  for (var j = 1; j <= titles.length; j++) {
    contents.push({
      id: j,
      title: titles[j - 1],
      category: cats[j % cats.length],
      author: (j % 3 === 0) ? 'admin' : 'editor',
      status: (j % 4 === 0) ? '草稿' : '已发布',
      date: '2026-1' + (j % 9 + 1) + '-' + (j % 27 + 1)
    });
  }

  /* ============================================================
     接真实后端示例（按需启用，替换上面的示例数据）
     约定字段：user{id,name,email,role,status} / content{id,title,category,author,status,date}
     ============================================================
     var API_BASE = 'https://your-api.com';
     function loadFromAPI() {
       fetch(API_BASE + '/users').then(r => r.json()).then(d => { users = d; renderUsers(); });
       fetch(API_BASE + '/contents').then(r => r.json()).then(d => { contents = d; renderContents(); renderDashboard(); });
     }
     // 把上方 for 循环生成的示例数据注释掉，初始渲染处改调 loadFromAPI() 即可
  */

  /* ---------------- 状态 ---------------- */
  var state = {
    view: 'dashboard',
    userPage: 1,
    contentPage: 1,
    userTerm: '',
    contentTerm: '',
    pageSize: 8
  };

  /* ---------------- 工具函数 ---------------- */
  function $(id) { return document.getElementById(id); }
  function statusBadge(s) {
    if (s === '启用' || s === '已发布') return '<span class="badge ok">' + s + '</span>';
    if (s === '草稿') return '<span class="badge warn">' + s + '</span>';
    return '<span class="badge bad">' + s + '</span>';
  }
  function esc(str) {
    return String(str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ---------------- 顶部用户信息 ---------------- */
  var uname = localStorage.getItem('admin_user') || 'admin';
  $('username').textContent = uname;
  $('avatar').textContent = uname.charAt(0).toUpperCase();

  /* ---------------- 侧栏 / 视图切换 ---------------- */
  $('toggleBtn').addEventListener('click', function () {
    $('sidebar').classList.toggle('collapsed');
  });

  var navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(function (item) {
    if (item.classList.contains('disabled')) return;
    item.addEventListener('click', function () {
      var view = item.getAttribute('data-view');
      if (!view) return;
      state.view = view;
      navItems.forEach(function (n) { n.classList.remove('active'); });
      item.classList.add('active');
      $('pageTitle').textContent = item.getAttribute('data-label') || item.textContent.trim();
      $('view-dashboard').classList.toggle('hidden', view !== 'dashboard');
      $('view-users').classList.toggle('hidden', view !== 'users');
      $('view-content').classList.toggle('hidden', view !== 'content');
      $('view-settings').classList.toggle('hidden', view !== 'settings');
      $('topSearch').value = (view === 'users') ? state.userTerm : (view === 'content' ? state.contentTerm : '');
      var ph = { dashboard: '搜索…', users: '搜索用户名 / 邮箱…', content: '搜索标题 / 作者…', settings: '' }[view] || '';
      $('topSearch').setAttribute('placeholder', ph);
    });
  });

  /* ---------------- 用户表格 ---------------- */
  function renderUsers() {
    var term = state.userTerm.toLowerCase();
    var list = users.filter(function (u) {
      return (u.name + u.email).toLowerCase().indexOf(term) > -1;
    });
    var total = Math.max(1, Math.ceil(list.length / state.pageSize));
    if (state.userPage > total) state.userPage = total;
    var start = (state.userPage - 1) * state.pageSize;
    var pageItems = list.slice(start, start + state.pageSize);

    var html = pageItems.map(function (u) {
      return '<tr>' +
        '<td>' + u.id + '</td>' +
        '<td>' + esc(u.name) + '</td>' +
        '<td>' + esc(u.email) + '</td>' +
        '<td>' + esc(u.role) + '</td>' +
        '<td>' + statusBadge(u.status) + '</td>' +
        '<td><div class="row-actions">' +
          '<button class="btn btn-ghost btn-sm" data-action="edit-user" data-id="' + u.id + '">编辑</button>' +
          '<button class="btn btn-danger btn-sm" data-action="del-user" data-id="' + u.id + '">删除</button>' +
        '</div></td>' +
      '</tr>';
    }).join('');
    if (!pageItems.length) html = '<tr><td colspan="6" style="text-align:center;color:var(--text-soft);padding:24px;">暂无数据</td></tr>';
    $('userTableBody').innerHTML = html;

    renderPagination($('userPagination'), state.userPage, total, function (p) {
      state.userPage = p; renderUsers();
    }, list.length);
  }

  /* ---------------- 内容表格 ---------------- */
  function renderContents() {
    var term = state.contentTerm.toLowerCase();
    var list = contents.filter(function (c) {
      return (c.title + c.author).toLowerCase().indexOf(term) > -1;
    });
    var total = Math.max(1, Math.ceil(list.length / state.pageSize));
    if (state.contentPage > total) state.contentPage = total;
    var start = (state.contentPage - 1) * state.pageSize;
    var pageItems = list.slice(start, start + state.pageSize);

    var html = pageItems.map(function (c) {
      return '<tr>' +
        '<td>' + c.id + '</td>' +
        '<td>' + esc(c.title) + '</td>' +
        '<td>' + esc(c.category) + '</td>' +
        '<td>' + esc(c.author) + '</td>' +
        '<td>' + statusBadge(c.status) + '</td>' +
        '<td>' + esc(c.date) + '</td>' +
        '<td><div class="row-actions">' +
          '<button class="btn btn-ghost btn-sm" data-action="edit-content" data-id="' + c.id + '">编辑</button>' +
          '<button class="btn btn-danger btn-sm" data-action="del-content" data-id="' + c.id + '">删除</button>' +
        '</div></td>' +
      '</tr>';
    }).join('');
    if (!pageItems.length) html = '<tr><td colspan="7" style="text-align:center;color:var(--text-soft);padding:24px;">暂无数据</td></tr>';
    $('contentTableBody').innerHTML = html;

    renderPagination($('contentPagination'), state.contentPage, total, function (p) {
      state.contentPage = p; renderContents();
    }, list.length);
  }

  /* ---------------- 分页组件 ---------------- */
  function renderPagination(container, current, total, onPage, count) {
    var btns = [];
    btns.push('<button class="page-btn" data-page="' + (current - 1) + '"' + (current === 1 ? ' disabled' : '') + '>上一页</button>');
    for (var p = 1; p <= total; p++) {
      btns.push('<button class="page-btn' + (p === current ? ' active' : '') + '" data-page="' + p + '">' + p + '</button>');
    }
    btns.push('<button class="page-btn" data-page="' + (current + 1) + '"' + (current === total ? ' disabled' : '') + '>下一页</button>');
    btns.push('<span class="page-info">共 ' + count + ' 条 · 第 ' + current + '/' + total + ' 页</span>');
    container.innerHTML = btns.join('');
    container.querySelectorAll('.page-btn[data-page]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var pg = parseInt(btn.getAttribute('data-page'), 10);
        if (!isNaN(pg) && pg >= 1 && pg <= total) onPage(pg);
      });
    });
  }

  /* ---------------- 搜索 ---------------- */
  $('userSearch').addEventListener('input', function (e) {
    state.userTerm = e.target.value; state.userPage = 1; renderUsers();
  });
  $('contentSearch').addEventListener('input', function (e) {
    state.contentTerm = e.target.value; state.contentPage = 1; renderContents();
  });
  $('topSearch').addEventListener('input', function (e) {
    if (state.view === 'users') { state.userTerm = e.target.value; state.userPage = 1; renderUsers(); $('userSearch').value = e.target.value; }
    else if (state.view === 'content') { state.contentTerm = e.target.value; state.contentPage = 1; renderContents(); $('contentSearch').value = e.target.value; }
    // 看板 / 设置页不做顶部搜索
  });

  /* ---------------- 操作（编辑 / 删除）事件委托 ---------------- */
  document.querySelector('.content').addEventListener('click', function (e) {
    var btn = e.target.closest('[data-action]');
    if (!btn) return;
    var action = btn.getAttribute('data-action');
    var id = parseInt(btn.getAttribute('data-id'), 10);

    if (action === 'del-user') {
      if (confirm('确定删除该用户？')) {
        users = users.filter(function (u) { return u.id !== id; });
        renderUsers();
      }
    } else if (action === 'edit-user') {
      openUserModal(id);
    } else if (action === 'del-content') {
      if (confirm('确定删除该内容？')) {
        contents = contents.filter(function (c) { return c.id !== id; });
        renderContents();
      }
    } else if (action === 'edit-content') {
      openContentModal(id);
    }
  });

  /* ---------------- 弹窗：用户 ---------------- */
  function openUserModal(id) {
    var m = $('userModal');
    if (id) {
      var u = users.find(function (x) { return x.id === id; });
      $('userModalTitle').textContent = '编辑用户';
      $('userId').value = u.id;
      $('uName').value = u.name;
      $('uEmail').value = u.email;
      $('uRole').value = u.role;
      $('uStatus').value = u.status;
    } else {
      $('userModalTitle').textContent = '新增用户';
      $('userForm').reset();
      $('userId').value = '';
    }
    m.classList.remove('hidden');
  }
  $('addUserBtn').addEventListener('click', function () { openUserModal(null); });
  $('userForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var id = $('userId').value;
    var data = {
      name: $('uName').value.trim(),
      email: $('uEmail').value.trim(),
      role: $('uRole').value,
      status: $('uStatus').value
    };
    if (id) {
      var u = users.find(function (x) { return x.id === parseInt(id, 10); });
      Object.assign(u, data);
    } else {
      data.id = users.length ? Math.max.apply(null, users.map(function (x) { return x.id; })) + 1 : 1;
      users.push(data);
    }
    $('userModal').classList.add('hidden');
    renderUsers();
  });

  /* ---------------- 弹窗：内容 ---------------- */
  function openContentModal(id) {
    var m = $('contentModal');
    if (id) {
      var c = contents.find(function (x) { return x.id === id; });
      $('contentModalTitle').textContent = '编辑内容';
      $('contentId').value = c.id;
      $('cTitle').value = c.title;
      $('cCategory').value = c.category;
      $('cAuthor').value = c.author;
      $('cStatus').value = c.status;
      $('cDate').value = c.date;
    } else {
      $('contentModalTitle').textContent = '新增内容';
      $('contentForm').reset();
      $('contentId').value = '';
      $('cDate').value = new Date().toISOString().slice(0, 10);
    }
    m.classList.remove('hidden');
  }
  $('addContentBtn').addEventListener('click', function () { openContentModal(null); });
  $('contentForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var id = $('contentId').value;
    var data = {
      title: $('cTitle').value.trim(),
      category: $('cCategory').value.trim(),
      author: $('cAuthor').value.trim(),
      status: $('cStatus').value,
      date: $('cDate').value
    };
    if (id) {
      var c = contents.find(function (x) { return x.id === parseInt(id, 10); });
      Object.assign(c, data);
    } else {
      data.id = contents.length ? Math.max.apply(null, contents.map(function (x) { return x.id; })) + 1 : 1;
      contents.push(data);
    }
    $('contentModal').classList.add('hidden');
    renderContents();
  });

  /* ---------------- 关闭弹窗 ---------------- */
  document.querySelectorAll('[data-close]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      $(btn.getAttribute('data-close')).classList.add('hidden');
    });
  });
  // 点击遮罩关闭
  document.querySelectorAll('.modal-overlay').forEach(function (ov) {
    ov.addEventListener('click', function (e) {
      if (e.target === ov) ov.classList.add('hidden');
    });
  });

  /* ---------------- 用户下拉 / 登出 ---------------- */
  $('userMenu').addEventListener('click', function (e) {
    e.stopPropagation();
    $('userDropdown').classList.toggle('hidden');
  });
  document.addEventListener('click', function () {
    $('userDropdown').classList.add('hidden');
  });
  $('logoutBtn').addEventListener('click', function () {
    localStorage.removeItem('admin_token');
    localStorage.removeItem('admin_user');
    window.location.href = 'index.html';
  });

  /* ---------------- 数据看板 ---------------- */
  function renderDashboard() {
    var totalUsers = users.length;
    var activeUsers = users.filter(function (u) { return u.status === '启用'; }).length;
    var totalContent = contents.length;
    var published = contents.filter(function (c) { return c.status === '已发布'; }).length;

    var stats = [
      { label: '总用户数', value: totalUsers, icon: '👥', grad: 'linear-gradient(135deg,#a8c0ff,#9bb8ff)' },
      { label: '启用用户', value: activeUsers, icon: '✅', grad: 'linear-gradient(135deg,#7fd1ae,#9bb8ff)' },
      { label: '内容总数', value: totalContent, icon: '📄', grad: 'linear-gradient(135deg,#ffc3a0,#ff9a8b)' },
      { label: '已发布', value: published, icon: '🚀', grad: 'linear-gradient(135deg,#fbc2eb,#ff9a8b)' }
    ];
    $('statGrid').innerHTML = stats.map(function (s) {
      return '<div class="stat-card">' +
        '<div class="stat-icon" style="background:' + s.grad + '">' + s.icon + '</div>' +
        '<div class="stat-meta"><div class="stat-value">' + s.value + '</div>' +
        '<div class="stat-label">' + s.label + '</div></div></div>';
    }).join('');

    var week = [3, 5, 2, 7, 4, 6, 5];
    var max = Math.max.apply(null, week);
    $('weekChart').innerHTML = week.map(function (v, i) {
      return '<div class="bar-wrap"><div class="bar" style="height:' + Math.round(v / max * 100) + '%"></div>' +
        '<span class="bar-label">周' + (i + 1) + '</span></div>';
    }).join('');
  }

  /* ---------------- 系统设置 ---------------- */
  function loadSettings() {
    var s = {};
    try { s = JSON.parse(localStorage.getItem('admin_settings') || '{}'); } catch (e) {}
    if (s.siteName) $('setSiteName').value = s.siteName;
    if (s.pageSize) { $('setPageSize').value = s.pageSize; state.pageSize = parseInt(s.pageSize, 10); }
    if (typeof s.notify !== 'undefined') $('setNotify').checked = s.notify;
  }
  $('settingsForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var s = {
      siteName: $('setSiteName').value.trim(),
      pageSize: $('setPageSize').value,
      notify: $('setNotify').checked
    };
    localStorage.setItem('admin_settings', JSON.stringify(s));
    state.pageSize = parseInt(s.pageSize, 10);
    renderUsers();
    renderContents();
    renderDashboard();
    var tip = $('settingsTip');
    tip.textContent = '已保存 ✓';
    setTimeout(function () { tip.textContent = ''; }, 2000);
  });

  /* ---------------- 初始渲染 ---------------- */
  loadSettings();
  renderUsers();
  renderContents();
  renderDashboard();
})();
